@extends('layouts.main')

@section('content')
    <div class="bidang-ekonomi">
        <div class="container">
            @include('components.section-header')
            <div class="body d-flex flex-column align-items-center">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
            </div>
        </div>
    </div>
@endsection
