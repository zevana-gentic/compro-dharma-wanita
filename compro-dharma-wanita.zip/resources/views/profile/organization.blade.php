@extends('layouts.main')

@section('content')
    <div class="struktur">
        <div class="container">
            @include('components.section-header')
            <div class="body d-flex flex-column align-items-center">
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi praesentium aperiam facere et. A
                    possimus ratione praesentium doloribus quibusdam voluptatem ut, voluptate nemo, dolorem officiis
                    expedita veritatis repudiandae ullam quas culpa temporibus, corrupti quaerat modi iste vero? Ipsa iste
                    sint sapiente atque eum eligendi et quas enim fuga, blanditiis reprehenderit.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi praesentium aperiam facere et. A
                    possimus ratione praesentium doloribus quibusdam voluptatem ut, voluptate nemo, dolorem officiis
                    expedita veritatis repudiandae ullam quas culpa temporibus, corrupti quaerat modi iste vero? Ipsa iste
                    sint sapiente atque eum eligendi et quas enim fuga, blanditiis reprehenderit.</p>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi praesentium aperiam facere et. A
                    possimus ratione praesentium doloribus quibusdam voluptatem ut, voluptate nemo, dolorem officiis
                    expedita veritatis repudiandae ullam quas culpa temporibus, corrupti quaerat modi iste vero? Ipsa iste
                    sint sapiente atque eum eligendi et quas enim fuga, blanditiis reprehenderit.</p>
            </div>
        </div>
    </div>
@endsection
