<div class="header">
    <div class="title mt-3">{{ $page_title }}</div>
    <div class="sub-title mb-5">{{ $page_sub_title }}</div>
</div>
