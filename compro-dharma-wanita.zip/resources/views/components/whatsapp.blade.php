<div class="sosmed">
    <a href="#" class="sosmed whatsapp"><i class="fa-brands fa-whatsapp"></i></a>
</div>
