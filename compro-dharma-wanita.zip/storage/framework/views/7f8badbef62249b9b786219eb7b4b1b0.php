<?php $__env->startSection('title'); ?>
    Edit Profil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <?php if($msg = Session::get('success')): ?>
            <div class="my-3 alert alert-success alert-dismissible show" role="alert">
                <strong><?php echo e($msg); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php elseif($errors->any()): ?>
            <div class="my-3 alert alert-danger alert-dismissible show" role="alert">
                <strong>Terjadi kesalahan saat pengisian form. Data yang masih salah akan ditandai dengan tulisan merah, silahkan cek kembali form Anda.</strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h6 class="card-title">Edit Profil</h6>
                        <form class="forms-sample" action="<?php echo e(route('member.profil-edit.submit')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputUsername1">Nama<span class="text-danger">*</span></label>
                                <input name="name" type="text" class="form-control" autocomplete="off" value="<?php echo e(Auth::user()->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email</label>
                                <input name="email" type="email" class="form-control" placeholder="Email" value="<?php echo e(Auth::user()->email); ?>" disabled>
                            </div>
                            <div class="form-group">
                                <label for="photo">Foto Profil<span class="text-danger">*</span></label>
                                <input name="photo" type="file" class="form-control" id="myDropify" data-default-file="<?php echo e(@$profile->photo ? asset('uploads/'.$profile->photo) : ''); ?>">
                                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <small class="text-danger"><?php echo e($message); ?></small>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="d-flex align-items-center justify-content-end">
                                
                                <button type="submit" class="btn btn-primary mr-2">Ubah</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <form class="forms-sample" action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <h6 class="card-title">Ganti Password</h6>
                            <div class="form-group">
                                <label for="old_password">Password Lama<span class="text-danger">*</span></label>
                                <input name="old_password" type="text" class="form-control" autocomplete="off">
                            </div>
                            <div class="form-group">
                                <label for="password">Password Baru<span class="text-danger">*</span></label>
                                <input name="password" type="password" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="password_confirmation">Konfirmasi Password Baru<span class="text-danger">*</span></label>
                                <input name="password_confirmation" type="password" class="form-control">
                            </div>
                            <a href="" class="text-primary">Lupa Password?</a>
                            <div class="d-flex align-items-center justify-content-end">
                                
                                <button type="submit" class="btn btn-primary mr-2">Ubah</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
          $('#myDropify').dropify({
            messages: {
                'default': 'Drag and drop file gambar atau klik disini.',
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/member/profil.blade.php ENDPATH**/ ?>