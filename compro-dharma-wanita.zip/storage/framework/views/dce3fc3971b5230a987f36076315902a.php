<?php $__env->startSection('content'); ?>
    <div class="galeri-video">
        <div class="container">
            <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="d-flex flex-wrap align-items-center justify-content-center">
                
                <?php $__currentLoopData = $gallery_videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <iframe width="400" height="250" src="<?php echo $item->video; ?>"
                    title="YouTube video player" frameborder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowfullscreen class="mx-1 my-1"></iframe>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php if($gallery_videos->count() > 0): ?>
                <div class="my-5">
                    <?php echo e($gallery_videos->links('components.pagination')); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/gallery/video.blade.php ENDPATH**/ ?>