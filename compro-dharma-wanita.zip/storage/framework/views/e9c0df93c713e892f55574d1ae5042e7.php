<?php $__env->startSection('content'); ?>
<div class="visimisi">
    <div class="container">
        <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="body d-flex flex-column align-items-center">
          <div class="visi">
              <div class="header mb-5">Visi</div>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
          </div>
          <div class="misi">
              <div class="header mb-5">Misi</div>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
              <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Omnis corporis fugiat culpa, nulla quibusdam molestias ut veritatis perferendis dolor? Beatae iusto eius veritatis, nulla corrupti distinctio rerum nesciunt id itaque quo expedita totam odit hic voluptatem modi odio dolor praesentium!</p>
          </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/profile/vision-mission.blade.php ENDPATH**/ ?>