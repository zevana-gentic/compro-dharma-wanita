<?php $__env->startSection('content'); ?>
    <div class="galeri-foto">
        <div class="container">
            <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="body d-flex flex-column align-items-center">
                <div class="d-flex justify-content-center">
                    <div id="gallery" class="text-center">
                        <?php $__currentLoopData = $gallery_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset('uploads/' . $item->photo)); ?>">
                                <img src="<?php echo e(asset('uploads/' . $item->photo)); ?>" height="250" alt="" class="mt-1">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php if($gallery_photos->count() > 0): ?>
                    <div class="mt-5">
                        <?php echo e($gallery_photos->links('components.pagination')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/gallery/photo.blade.php ENDPATH**/ ?>