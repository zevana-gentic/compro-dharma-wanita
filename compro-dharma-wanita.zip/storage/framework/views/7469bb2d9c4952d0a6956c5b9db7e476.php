<?php $__env->startSection('content'); ?>
    <section class="detail-berita">
        <div class="container">
            <div class="body detail-berita-content">
                <div class="row">
                    <div class="col-md-8">
                        <img src="<?php echo e(asset('uploads/'. $news->image_thumbnail)); ?>" alt="" class="mb-3">
                        <span class="date-author"><i class="fa-regular fa-calendar me-1"></i><?php echo e($news->created_at->format("j M Y")); ?></span>
                        <span class="date-author"><i class="fa-solid fa-user me-1"></i><?php echo e($news->author); ?></span>
                        <span class="date-author"><i class="fa-solid fa-layer-group me-1"></i></i><?php echo e($news->category); ?></span>
                        <div class="title mt-3"><?php echo e($news->title); ?></div>
                        <p><?php echo $news->content; ?></p>
                    </div>
                    <div class="col-md-4">
                        <div class="header-berita-terbaru text-center">Berita Terbaru</div>
                        <div class="cards">
                            <?php $__currentLoopData = $recent_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="mt-3">
                                    <a href="<?php echo e(route('pages.news-detail', ['slug' => $item->slug])); ?>" class="card-berita-terbaru">
                                        <div class="row">
                                            <div class="col-4">
                                                <img src="<?php echo e(asset('uploads/'. $item->image_thumbnail)); ?>" height="100" alt="">
                                            </div>
                                            <div class="col-8">
                                                <div class="card-berita-body d-flex flex-column justify-content-center">
                                                    <div class="title"><?php echo e($item->title); ?>.</div>
                                                    <div class="date"><?php echo e($item->created_at->format("j M Y")); ?></div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/news/news-detail.blade.php ENDPATH**/ ?>