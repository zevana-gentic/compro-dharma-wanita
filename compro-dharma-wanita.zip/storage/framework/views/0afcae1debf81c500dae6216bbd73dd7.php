<?php $__env->startSection('title'); ?>
    Dashboard Member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
            <div>
                <h4 class="mb-3 mb-md-0">Selamat Datang di Dashboard Member DWP</h4>
            </div>
            
        </div>

        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/member/dashboard.blade.php ENDPATH**/ ?>