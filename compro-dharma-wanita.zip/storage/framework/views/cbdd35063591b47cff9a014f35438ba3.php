<div class="card my-3">
    <img src="<?php echo e(asset('uploads/' . @$item->image_thumbnail)); ?>" class="img-berita" alt="" />
    <div class="card-body">
        <div class="title"><?php echo e($item->title); ?></div>
        <div class="card-text my-2">
            <p>
                <?php echo @$item->content; ?>

            </p>
        </div>
        <div class="d-flex mt-3 mb-2">
            <div class="date w-50 h-25 d-flex align-items-center">
                <i class="fa-regular fa-calendar"></i>
                <div class="ms-1"><?php echo e(@$item->created_at->format("j M Y")); ?></div>
            </div>
            <a href="<?php echo e(route('pages.news-detail', ['slug' => @$item->slug])); ?>" class="selengkapnya w-50 text-end">Selengkapnya<i
                    class="fa-solid fa-angle-right ms-1"></i></a>
        </div>
    </div>
</div>
<?php /**PATH E:\FL\compro-dharma-wanita\resources\views/components/card.blade.php ENDPATH**/ ?>