<?php $__env->startSection('title'); ?>
    List Data Galeri - Foto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container">
        <div class="justify-content-between align-items-center flex-wrap grid-margin">
            <h4>List Data Galeri - Foto</h4>
            <div class="row mt-3">
                <div class="col-md-3">
                    <a href="<?php echo e(route('gallery.photo.add')); ?>" class="btn btn-primary btn-md" title="Tambah Foto">
                        <i class="mr-1" data-feather="plus-circle" style="width: 20px; height:20px;"></i>
                        Tambah Foto
                    </a>
                </div>
                
            </div>
        </div>
        <?php if($msg = Session::get('success')): ?>
            <div class="my-3 alert alert-success alert-dismissible show" role="alert">
                <strong><?php echo e($msg); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php elseif($msg = Session::get('error')): ?>
            <div class="my-3 alert alert-danger alert-dismissible show" role="alert">
                <strong><?php echo e($msg); ?></strong>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <div class="table-responsive pt-1">
                    <table class="table table-bordered table-striped table-hover" width="500px">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Gambar</th>
                                <th>Tanggal Posting</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="text-wrap text-capitalize"><?php echo e($loop->iteration); ?></td>
                                    <td class="d-flex justify-content-center">
                                        <div class="card" style="width: 250px; border: none;">
                                            <div class="card-body" style="width: 100%; height: 200px; background-image: url('<?php echo e(asset('uploads/'. $item->photo)); ?>'); background-size: cover; background-position: center; "></div>
                                        </div>
                                    </td>
                                    <td><?php echo e(date_format($item->created_at, "d M Y")); ?></td>
                                    <td>
                                        <a class="btn btn-success btn-icon btn-edit mr-2" href="<?php echo e(route('gallery.photo.edit', $item->id)); ?>"><i data-feather="edit"></i></a>
                                        <a class="btn btn-danger btn-hapus btn-icon" data-toggle="modal" data-target="#hapusdata" data-id="<?php echo e($item->id); ?>"><i data-feather="trash"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="4">Belum ada data foto.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="mt-3">
                       <?php echo e($photos->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
  <div class="modal fade" id="hapusdata" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Hapus</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="" method="POST" class="form-delete">
            <?php echo csrf_field(); ?>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus data foto ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-danger">Hapus</button>
            </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $('.btn-hapus').on('click', function() {
            const id = $(this).data('id');
            $('.form-delete').attr('action', '<?php echo e(url('admin')); ?>/photo-delete/'+id);
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/admin/gallery-photo-list.blade.php ENDPATH**/ ?>