<div class="header">
    <div class="title mt-3"><?php echo e($page_title); ?></div>
    <div class="sub-title mb-5"><?php echo e($page_sub_title); ?></div>
</div>
<?php /**PATH E:\FL\compro-dharma-wanita\resources\views/components/section-header.blade.php ENDPATH**/ ?>