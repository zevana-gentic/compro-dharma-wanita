<?php $__env->startSection('content'); ?>
    <div class="tugas-fungsi">
        <div class="container">
            <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="body d-flex flex-column align-items-center">
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum molestiae dolore dignissimos qui!
                    Accusamus eligendi distinctio repudiandae a dignissimos? Architecto, praesentium dolorum molestiae
                    veniam saepe asperiores officia aperiam voluptate explicabo facilis necessitatibus, vel, repellendus
                    nobis ducimus dolore illo doloremque similique qui sint exercitationem culpa sequi a hic quas? Saepe,
                    ipsa?</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/profile/task-functions.blade.php ENDPATH**/ ?>