<?php $__env->startSection('title'); ?>
    Detail Anggota DWP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="row">
            <div class="banner" style="width: 100%;">
                <img src="<?php echo e(asset('assets/banner.png')); ?>" alt=""
                    style="width: 100%; height:250px; border-radius: 1em; object-fit: cover; object-position: center;">
            </div>
            <div class="profile w-100 d-flex flex-column align-items-center">
                <img src="https://ui-avatars.com/api/?background=f9c346&size=30&name=<?php echo e(str_replace(' ', '+', $member->name)); ?>"
                    width="150" height="150" alt=""
                    style="border-radius: 100%; border: 5px solid white; margin-top: -75px;">
                <div class="name mt-2" style="font-size: 2rem; font-weight: 600;"><?php echo e($member->name); ?></div>
                <div class="email" style="font-size: 1rem;"><?php echo e($member->email); ?></div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="detail-profile mt-4 card p-4">
                    <div class="section-name text-center mb-1" style="font-size: 2rem; font-weight: 800;">PROFIL</div>
                    <div class="member-name" style="font-weight: 800;">NAMA ANGGOTA :</div>
                    <div class="mamber-name"><?php echo e($member->name); ?></div>
                    <hr />
                    <div class="member-name" style="font-weight: 800;">EMAIL :</div>
                    <div class="mamber-name"><?php echo e($member->email); ?></div>
                    <hr />
                    <div class="member-name" style="font-weight: 800;">TANGGAL DAFTAR :</div>
                    <div class="mamber-name"><?php echo e($member->created_at->format('j M Y')); ?></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/admin/dwp-member-detail.blade.php ENDPATH**/ ?>