<?php $__env->startSection('title'); ?>
    List Anggota DWP
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container">
            <div class="justify-content-between align-items-center flex-wrap grid-margin">
                <div>
                    <h4 class="mb-3 mb-md-0">List Anggota DWP</h4>
                    <br>
                    <div class="row">
                        
                        <div class="col-md-6">
                            <form action="" method="GET">
                                <div class="input-group ml-1 mb-3 row justify-content right">
                                    <input type="text" class="form-control" placeholder="Cari Anggota" name="q">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-primary" type="submit" title="Search">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive pt-1">
                        <table class="table table-bordered table-striped table-hover" width="500px">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Nama Anggota</th>
                                    <th>Email</th>
                                    <th>Tanggal Registrasi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td class="text-warning"><b><?php echo e($item->email); ?></b></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->translatedFormat('l, d F Y (h:i:s A)')); ?></td>
                                            <td>
                                                <a class="btn btn-warning btn-icon mr-2" href="<?php echo e(route('dwp-member.detail', $item->id)); ?>"><i data-feather="eye"></i></a>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="5" class="text-center">Belum ada data anggota.</td>
                                        </tr>
                                    <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="mt-3">
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/admin/dwp-member-list.blade.php ENDPATH**/ ?>