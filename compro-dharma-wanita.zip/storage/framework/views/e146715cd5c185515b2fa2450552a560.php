<nav class="navbar navbar-expand-lg">
    <div class="container">
        <div class="container-fluid">
            <a class="navbar-brand" href="/"><img src="<?php echo e(asset('assets/logo.png')); ?>" alt="logo" width="40" height="40"></a>
            <button class="navbar-toggler float-end" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('pages.index') ? 'active' : ''); ?>" aria-current="page"
                            href="<?php echo e(route('pages.index')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link <?php echo e(Route::is(['pages.history', 'pages.vision-mission', 'pages.task-functions', 'pages.organization']) ? 'active' : ''); ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Profil
                        </a>

                        <ul class="dropdown-menu">

                            <li><a class="dropdown-item <?php echo e(Route::is('pages.history') ? 'active' : ''); ?>" href="<?php echo e(route('pages.history')); ?>">Sejarah</a></li>
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.vision-mission') ? 'active' : ''); ?>" href="<?php echo e(route('pages.vision-mission')); ?>">Visi dan Misi</a></li>
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.task-functions') ? 'active' : ''); ?>" href="<?php echo e(route('pages.task-functions')); ?>">Tugas dan Fungsi</a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.organization') ? 'active' : ''); ?>" href="<?php echo e(route('pages.organization')); ?>">Struktur Organisasi</a>
                            </li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link <?php echo e(Route::is(['page.secretariat', 'pages.inspectorate', 'pages.education-office']) ? 'active' : ''); ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Unsur Pelaksana
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.secretariat') ? 'active' : ''); ?>" href="<?php echo e(route('pages.secretariat')); ?>">DWP Sekretariat Daerah</a>
                            </li>
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.inspectorate') ? 'active' : ''); ?>" href="<?php echo e(route('pages.inspectorate')); ?>">DWP Inspektorat</a></li>
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.education-office') ? 'active' : ''); ?>" href="<?php echo e(route('pages.education-office')); ?>">DWP Dinas Pendidikan</a>
                            </li>
                            
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link <?php echo e(Route::is(['pages.education', 'pages.socio-cultural', 'pages.economy']) ? 'active' : ''); ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Program Kerja
                        </a>
                        <ul class="dropdown-menu">
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.education') ? 'active' : ''); ?>" href="<?php echo e(route('pages.education')); ?>">Bidang Pendidikan</a>
                            </li>
                            <li>
                                <a class="dropdown-item <?php echo e(Route::is('pages.socio-cultural') ? 'active' : ''); ?>" href="<?php echo e(route('pages.socio-cultural')); ?>">Bidang Sosial Budaya</a>
                            </li>
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.economy') ? 'active' : ''); ?>" href="<?php echo e(route('pages.economy')); ?>">Bidang Ekonomi</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('pages.news') ? 'active' : ''); ?>"
                            href="<?php echo e(route('pages.news')); ?>">Berita</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link <?php echo e(Route::is(['pages.gallery-photo', 'pages.gallery-video']) ? 'active' : ''); ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Galeri
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.gallery-photo') ? 'active' : ''); ?>" href="<?php echo e(route('pages.gallery-photo')); ?>">Galeri Foto</a></li>
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.gallery-video') ? 'active' : ''); ?>" href="<?php echo e(route('pages.gallery-video')); ?>">Galeri Video</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link <?php echo e(Route::is(['pages.external_information', 'pages.internal_information']) ? 'active' : ''); ?> dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Informasi
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.external-information') ? 'active' : ''); ?>" href="<?php echo e(route('pages.external-information')); ?>">Eksternal</a></li>
                            <li><a class="dropdown-item <?php echo e(Route::is('pages.internal-information') ? 'active' : ''); ?>" href="<?php echo e(route('pages.internal-information')); ?>">Internal</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(Route::is('pages.contact-us') ? 'active' : ''); ?>"
                            href="<?php echo e(route('pages.contact-us')); ?>">Kontak Kami</a>
                    </li>
                </ul>
                <?php if(auth()->guard()->guest()): ?>
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">Daftar</a>
                        </li>
                    </ul>
                
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH E:\FL\compro-dharma-wanita\resources\views/components/navbar.blade.php ENDPATH**/ ?>