<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?> - Dharma Wanita Persatuan</title>
    <link rel="stylesheet" href="<?php echo e(asset('noble')); ?>/assets/vendors/jquery-tags-input/jquery.tagsinput.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('noble')); ?>/assets/css/demo_1/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('noble')); ?>/assets/vendors/core/core.css">
    <link rel="stylesheet" href="<?php echo e(asset('noble')); ?>/assets/vendors/dropify/dist/dropify.min.css">
    <?php echo $__env->yieldContent('css'); ?>
    
</head>

<body>
    <div class="main-wrapper">
        <?php echo $__env->make('components.sidebar-member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <?php echo $__env->make('components.navbar-member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

            <footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between">
                <p class="text-muted text-center text-md-left">Copyright © 2024
                    
                    All rights reserved
                </p>
            </footer>
        </div>
    </div>

    <!-- core:js -->
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/core/core.js"></script>
    
    
    
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/apexcharts/apexcharts.min.js"></script>
    
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/feather-icons/feather.min.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/js/template.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/js/dashboard.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/js/datepicker.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/jquery-tags-input/jquery.tagsinput.min.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/dropify/dist/dropify.min.js"></script>
    <script src="<?php echo e(asset('noble')); ?>/assets/vendors/tinymce/tinymce.js"></script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH E:\FL\compro-dharma-wanita\resources\views/layouts/member-dashboard.blade.php ENDPATH**/ ?>