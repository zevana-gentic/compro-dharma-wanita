<?php $__env->startSection('title'); ?>
    Masuk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php elseif($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
            <strong><?php echo e($message); ?></strong>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <form action="<?php echo e(route('login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="email" class="form-label">Email :</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" id="email">
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password :</label>
            <div class="form-group" style="position: relative;">
                <input name="password" type="password" class="form-control" id="password-field">
                <span toggle="#password-field" class="fa-solid fa-eye toggle-password"
                    style="position: absolute; right:20px; top:10px; cursor: pointer;">
                </span>
            </div>
        </div>
        <div class="mb-3">
            <a href="" class="text-decoration-none" style="color:#FFBB5C;"><b>Lupa Password</b></a>
        </div>
        <div class="mb-3">
            <button type="submit" class="btn-auth fw-bold w-100">Masuk</button>
        </div>
    </form>
    <p class="text-center">Belum punya akun? <a href="<?php echo e(route('register')); ?>" class="text-decoration-none" style="color:#FFBB5C;"><b>Daftar</b></a></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $(".toggle-password").click(function() {
       $(this).toggleClass("fa-eye fa-eye-slash");
       var input = $($(this).attr("toggle"));

       if (input.attr("type") == "password") {
           input.attr("type", "text");
       } else {
           input.attr("type", "password");
       }
   });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/auth/login.blade.php ENDPATH**/ ?>