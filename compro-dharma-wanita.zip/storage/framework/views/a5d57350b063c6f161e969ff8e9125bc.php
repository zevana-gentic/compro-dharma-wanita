<?php $__env->startSection('content'); ?>
    <div class="sejarah">
        <div class="container">
            <?php echo $__env->make('components.section-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="body">
                <p>
                    Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolores
                    autem at minus est quae recusandae magnam nostrum illum velit modi?
                    Non velit, fuga cupiditate ipsum eaque id, dolores vel cum ratione,
                    commodi doloremque ducimus. Atque expedita, commodi at tempora autem
                    animi blanditiis quidem quae, eaque nesciunt aliquam in repudiandae.
                    Quia, id. Exercitationem autem iusto aliquam minima rerum eveniet ab
                    dolorum, similique, corporis deleniti sunt facere sequi nisi labore
                    beatae quo libero maiores officiis numquam voluptatem. Optio facilis
                    velit voluptatem soluta quibusdam eveniet mollitia, in doloremque
                    sed quae minus inventore sit? Velit quod vel nulla minus deleniti
                    repudiandae a natus molestiae.
                </p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolore
                    error odit amet soluta explicabo vero veniam ipsam totam architecto
                    consequatur, neque vitae laborum inventore ducimus provident
                    molestiae sapiente recusandae sit ad. Placeat officiis illo deleniti
                    enim omnis sequi facere tempore, rem ex dolores blanditiis!
                    Praesentium impedit culpa obcaecati. Est animi placeat odio quo sunt
                    voluptatibus in, voluptatem labore temporibus beatae deserunt culpa
                    commodi exercitationem quisquam architecto perspiciatis magnam
                    excepturi maxime! Non, tempora? Qui quibusdam dicta laborum
                    voluptatibus, facilis perspiciatis ea. Ipsum vitae architecto
                    repellendus nobis corporis ea obcaecati rerum natus? Facere commodi
                    fugit, quia labore laudantium aliquid itaque facilis? Sit quasi
                    maiores ab explicabo pariatur, et numquam facere nihil labore sequi
                    atque molestiae. Iure odit quis eos iusto obcaecati repudiandae
                    molestias eligendi voluptatibus maxime enim!
                </p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\FL\compro-dharma-wanita\resources\views/profile/history.blade.php ENDPATH**/ ?>